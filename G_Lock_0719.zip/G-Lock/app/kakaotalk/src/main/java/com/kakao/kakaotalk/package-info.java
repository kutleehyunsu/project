/**
 * 카카오톡 API를 제공한다.
 */
package com.kakao.kakaotalk;