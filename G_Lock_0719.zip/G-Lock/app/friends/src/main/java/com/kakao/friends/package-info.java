/**
 * 해당 앱의 친구나 talk, story 친구리스트와 각 친구의 정보를 제공한다.
 */
package com.kakao.friends;