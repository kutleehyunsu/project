package com.kakao.sdk.sample.kakaostory;

import com.kakao.friends.response.model.FriendInfo;
import com.kakao.sdk.sample.friends.FriendsMainActivity;

/**
 * @author leo.shin
 */
public class KakaoStoryFriendListActivity extends FriendsMainActivity {
    @Override
    public void onItemSelected(int position, FriendInfo friendInfo) {
        super.onItemSelected(position, friendInfo);
    }
}
