package com.example.lee.g_lock;

/**
 * Created by e12hs_000 on 2016-07-07.
 */

import android.annotation.SuppressLint;
import android.os.StrictMode;

public class NetworkUtil {
    @SuppressLint("NewApi")
    static public void setNetworkPolicy() {
        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
    }
}
