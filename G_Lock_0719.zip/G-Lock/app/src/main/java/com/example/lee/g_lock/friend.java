package com.example.lee.g_lock;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.kakao.kakaolink.KakaoLink;
import com.kakao.kakaolink.KakaoTalkLinkMessageBuilder;
import com.kakao.util.KakaoParameterException;

import java.util.Random;

/**
 * Created by e12hs_000 on 2016-05-22.
 */
public class friend extends AppCompatActivity {
    TextView password;
    Random rand;
    int count=0;
    int R_num;
    String num = "";

    private KakaoLink kakaoLink;
    private KakaoTalkLinkMessageBuilder kakaoTalkLinkMessageBuilder;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.friend);

        try {
            kakaoLink = KakaoLink.getKakaoLink(getApplicationContext());
            kakaoTalkLinkMessageBuilder = kakaoLink.createKakaoTalkLinkMessageBuilder();
        } catch (KakaoParameterException e) {
            e.getMessage();
        }

        password = (TextView)findViewById(R.id.disposable_password);
        rand = new Random();


    }

    private void sendLink(){
        try {
            kakaoTalkLinkMessageBuilder.addText("일회용 비밀번호 :" + num);
            final String linkContents = kakaoTalkLinkMessageBuilder.build();
            kakaoLink.sendMessage(kakaoTalkLinkMessageBuilder, this);
        } catch (KakaoParameterException e) {
            e.getMessage();
        }
    }

    public void onClick(View view){
        if(view.getId() == R.id.password_formation){

            for(int i=0;i<8;i++) {
                R_num = getRandom(9, 0);
                num = num + String.valueOf(R_num);
            }
            count++;
            password.setText(num);
            password.invalidate();
        }
        else if(view.getId()==R.id.kakao){
            if(count==0){
                Toast toast = Toast.makeText(this, "비밀번호를 먼저 생성하세요.", Toast.LENGTH_SHORT );
                toast.show();
            }
            else{
                sendLink();

                /*Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, R_num);
                sendIntent.setType("Text/plain");
                startActivity(Intent.createChooser(sendIntent, "선택하세요"));
                */
            }
        }
    }
    public int getRandom(int max, int offset){
        int result = rand.nextInt(max) + offset;

        return result;
    }
}
