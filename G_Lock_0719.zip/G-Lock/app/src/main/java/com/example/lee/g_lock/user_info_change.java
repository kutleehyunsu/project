package com.example.lee.g_lock;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


import java.io.OutputStream;

import java.net.HttpURLConnection;
import java.net.MalformedURLException;

/**
 * Created by e12hs_000 on 2016-05-22.
 */
public class user_info_change extends AppCompatActivity {
    String id;
    String pw;
    String doorpw;
    String name;
    String ipaddr;
    String serial;
    TextView cg_id, cg_name,  cg_ipaddr, cg_serial ;
    EditText cg_pw, cg_doorpw;

    private final String urlPath = "http://192.168.0.11/glock/user_info.php";
    private final String TAG = "PHPTEST";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_info_change);
        cg_id = (TextView)findViewById(R.id.user_cg_id);
        cg_pw = (EditText)findViewById(R.id.user_cg_pw);
        cg_doorpw = (EditText)findViewById(R.id.user_cg_doorpw);
        cg_name = (TextView)findViewById(R.id.user_cg_name);
        cg_ipaddr = (TextView)findViewById(R.id.user_cg_ipaddress);
        cg_serial = (TextView)findViewById(R.id.user_cg_serial);
        Intent intent = getIntent();
        id = intent.getExtras().getString("id");
        pw = intent.getExtras().getString("pw");
        doorpw = intent.getExtras().getString("doorpw");
        name = intent.getExtras().getString("name");
        ipaddr = intent.getExtras().getString("ipaddr");
        serial = intent.getExtras().getString("serial");

        cg_id.setText(id);
        cg_name.setText(name);
        cg_ipaddr.setText(ipaddr);
        cg_serial.setText(serial);
    }

    public void onClick(View view){
        if(view.getId() == R.id.user_info_change_ok){
            try {
                PHPRequest request = new PHPRequest("http://127.0.0.1/test/Data_insert.php");
                String result = request.PhPtest(id ,String.valueOf(cg_pw.getText()),String.valueOf(cg_doorpw.getText()));
                if(result.equals("1")){
                    Toast.makeText(getApplication(), "들어감", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(getApplication(),"안 들어감",Toast.LENGTH_SHORT).show();
                }
            }catch (MalformedURLException e){
                e.printStackTrace();
            }

        }
        else if(view.getId() == R.id.user_info_change_cancle){
            Intent intent = new Intent(this, user_info.class);
            intent.putExtra("id", id);
            intent.putExtra("pw", pw);
            intent.putExtra("doorpw", doorpw);
            intent.putExtra("name", name);
            intent.putExtra("ipaddr", ipaddr);
            intent.putExtra("serial", serial);
            startActivity(intent);
        }
    }


}
