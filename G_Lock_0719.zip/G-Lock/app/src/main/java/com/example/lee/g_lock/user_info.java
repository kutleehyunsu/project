package com.example.lee.g_lock;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

/**
 * Created by e12hs_000 on 2016-05-22.
 */
public class user_info extends AppCompatActivity {
    String id;
    String pw;
    String doorpw;
    String name;
    String ipaddr;
    String serial;
    TextView u_id, u_pw, u_doorpw, u_name, u_ipaddr, u_serial, cg_id, cg_name ;
    EditText cg_pw, cg_doorpw,  cg_ipaddr, cg_serial;
   // phpDown task;
    //int db_total; //db 개수
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_info);
        u_id = (TextView)findViewById(R.id.user_ori_id);
        u_pw = (TextView)findViewById(R.id.user_ori_pw);
        u_doorpw = (TextView)findViewById(R.id.user_ori_doorpw);
        u_name = (TextView)findViewById(R.id.user_ori_name);
        u_ipaddr = (TextView)findViewById(R.id.user_ori_ipaddress);
        u_serial = (TextView)findViewById(R.id.user_ori_serial);
        cg_id = (TextView)findViewById(R.id.user_cg_id);
        cg_pw = (EditText)findViewById(R.id.user_cg_pw);
        cg_doorpw = (EditText)findViewById(R.id.user_cg_doorpw);
        cg_name = (TextView)findViewById(R.id.user_cg_name);
        Intent intent = getIntent();
        id = intent.getExtras().getString("id");
        pw = intent.getExtras().getString("pw");
        doorpw = intent.getExtras().getString("doorpw");
        name = intent.getExtras().getString("name");
        ipaddr = intent.getExtras().getString("ipaddr");
        serial = intent.getExtras().getString("serial");
       // task = new phpDown();
        //task.execute("http://192.168.0.11/glock/user_info.php");
        u_id.setText(id);
        u_pw.setText(pw);
        u_doorpw.setText(doorpw);
        u_name.setText(name);
        u_ipaddr.setText(ipaddr);
        u_serial.setText(serial);

    }
/*
    private class phpDown extends AsyncTask<String, Integer,String> {
        @Override
        protected String doInBackground(String... urls) {
            StringBuilder jsonHtml = new StringBuilder();
            try{
                // 연결 url 설정
                URL url = new URL(urls[0]);
                // 커넥션 객체 생성
                HttpURLConnection conn = (HttpURLConnection)url.openConnection();
                // 연결되었으면.
                if(conn != null){
                    conn.setConnectTimeout(10000);
                    conn.setUseCaches(false);
                    // 연결되었음 코드가 리턴되면.
                    if(conn.getResponseCode() == HttpURLConnection.HTTP_OK){
                        String id_data  = URLEncoder.encode("user_id", "UTF-8") + "=" + URLEncoder.encode(user_id, "UTF-8");
                        conn.setDoOutput(true);
                        OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
                        wr.write(id_data);
                        wr.flush();
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                        for(;;){
                            // 웹상에 보여지는 텍스트를 라인단위로 읽어 저장.
                            String line = br.readLine();
                            if(line == null) break;
                            // 저장된 텍스트 라인을 jsonHtml에 붙여넣음
                            jsonHtml.append(line + "\n");
                        }
                        br.close();
                    }
                    conn.disconnect();
                }
            } catch(Exception ex){
                ex.printStackTrace();
            }
            return jsonHtml.toString();
        }
        protected void onPostExecute(String str){
            String id;
            String id_password;
            String doorlock_password;
            String user_name;
            String ip_address;
            String serial_number;

            try{
                JSONObject root = new JSONObject(str);
                JSONArray ja = root.getJSONArray("results");
                for(int i=0; i<ja.length(); i++){
                    JSONObject jo = ja.getJSONObject(i);
                    id = jo.getString("id");
                    id_password = jo.getString("id_password");
                    doorlock_password = jo.getString("doorlock_password");
                    user_name = jo.getString("username");
                    ip_address = jo.getString("ip_address");
                    serial_number = jo.getString("serial_number");
                    db_total = ja.length();
                    A_id.add(id);
                    A_pw.add(id_password);
                    A_name.add(user_name);
                    A_doorpw.add(doorlock_password);
                    A_ipaddr.add(ip_address);
                    A_serial.add(serial_number);
                }
            }catch(JSONException e){
                e.printStackTrace();
            }
        }
    }
*/
    public void onClick(View view){
        if(view.getId() == R.id.user_info_change){
            Intent intent = new Intent(this, user_info_change.class);
            intent.putExtra("id", id);
            intent.putExtra("pw", pw);
            intent.putExtra("doorpw", doorpw);
            intent.putExtra("name", name);
            intent.putExtra("ipaddr", ipaddr);
            intent.putExtra("serial", serial);
            startActivity(intent);
        }
        else if(view.getId() == R.id.user_info_cancle){
            Intent intent = new Intent(this, menu.class);
            intent.putExtra("id", id);
            intent.putExtra("pw", pw);
            intent.putExtra("doorpw", doorpw);
            intent.putExtra("name", name);
            intent.putExtra("ipaddr", ipaddr);
            intent.putExtra("serial", serial);
            startActivity(intent);
        }

    }
}
