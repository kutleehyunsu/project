package com.example.lee.g_lock;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

/**
 * Created by e12hs_000 on 2016-05-22.
 */
public class menu extends AppCompatActivity {
    String id;
    String pw;
    String doorpw;
    String name;
    String ipaddr;
    String serial;
    TextView test;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu);
        Intent intent = getIntent();
        id = intent.getExtras().getString("id");
        pw = intent.getExtras().getString("pw");
        doorpw = intent.getExtras().getString("doorpw");
        name = intent.getExtras().getString("name");
        ipaddr = intent.getExtras().getString("ipaddr");
        serial = intent.getExtras().getString("serial");
        test = (TextView)findViewById(R.id.test);
        test.setText(id);
    }

    public void onClick(View view){
        if(view.getId() == R.id.B_remote){
            Intent intent = new Intent(this, remote.class);
            startActivity(intent);
        }
        else if(view.getId() == R.id.B_log){
            Intent intent = new Intent(this, log_check.class);
            startActivity(intent);
        }
        else if(view.getId() == R.id.B_friend){
            Intent intent = new Intent(this, friend.class);
            startActivity(intent);
        }
        else if(view.getId() == R.id.B_user){
            Intent intent = new Intent(this, user_info.class);
            intent.putExtra("id", id);
            intent.putExtra("pw", pw);
            intent.putExtra("doorpw", doorpw);
            intent.putExtra("name", name);
            intent.putExtra("ipaddr", ipaddr);
            intent.putExtra("serial", serial);
            startActivity(intent);
        }
        else if(view.getId() == R.id.B_clock){
            Intent intent = new Intent(this, security.class);
            startActivity(intent);
        }
        else if(view.getId() == R.id.logout){
            Intent intent = new Intent(this, main.class);
            startActivity(intent);

        }
    }
}
