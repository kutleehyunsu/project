package com.example.lee.g_lock;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

/**
 * Created by e12hs_000 on 2016-05-22.
 */
public class security extends AppCompatActivity {
    ImageButton B_sun,B_mon,B_tues,B_wens,B_thurs,B_fri,B_sat;
    TextView s_time, e_time;
    public int mHour,mMinute; //현재시간
    public String hour,minute; // 입력받는변수
    String week = ""; //버튼누른 현재요일
    String sun_s = "00:00", sun_e= "00:00", mon_s= "00:00", mon_e= "00:00", tues_s= "00:00", tues_e= "00:00", wens_s= "00:00",
            wens_e= "00:00", thurs_s= "00:00", thurs_e= "00:00", fri_s= "00:00", fri_e= "00:00", sat_s= "00:00", sat_e= "00:00";
    // 요일별 시작, 종료시간 초기값 00 : 00
    static final int TIME_DIALOG_ID_S = 1;
    static final int TIME_DIALOG_ID_E = 2;

    public security(){
        final Calendar c = Calendar.getInstance();
        mHour = c.get(Calendar.HOUR_OF_DAY);
        mMinute = c.get(Calendar.MINUTE);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.security);
        B_sun = (ImageButton)findViewById(R.id.sun);
        B_mon = (ImageButton)findViewById(R.id.mon);
        B_tues = (ImageButton)findViewById(R.id.tues);
        B_wens = (ImageButton)findViewById(R.id.wens);
        B_thurs = (ImageButton)findViewById(R.id.thurs);
        B_fri = (ImageButton)findViewById(R.id.fri);
        B_sat = (ImageButton)findViewById(R.id.sat);
        s_time = (TextView)findViewById(R.id.start_time_v);
        e_time = (TextView)findViewById(R.id.end_time_v);
    }

    private TimePickerDialog.OnTimeSetListener mTimeSetListener_s = new TimePickerDialog.OnTimeSetListener(){
        public void onTimeSet(TimePicker view, int hourOfDay, int min){
            if(hourOfDay<10) hour = "0"+String.valueOf(hourOfDay);
            else hour = String.valueOf(hourOfDay);

            if(min<10) minute = "0"+String.valueOf(min);
            else minute = String.valueOf(min);

            if(week == "sun") {
                sun_s = hour + ":" + minute;
                s_time.setText(sun_s);
                s_time.invalidate();
            }
            else if(week == "mon"){
                mon_s =hour +  ":" +minute;
                s_time.setText(mon_s);
                s_time.invalidate();
            }
            else if(week == "tues"){
                tues_s = hour + ":" + minute;
                s_time.setText(tues_s);
                s_time.invalidate();
            }
            else if(week == "wens"){
                wens_s = hour + ":" + minute;
                s_time.setText(wens_s);
                s_time.invalidate();
            }
            else if(week == "thurs"){
                thurs_s = hour +  ":" +minute;
                s_time.setText(thurs_s);
                s_time.invalidate();
            }
            else if(week == "fri"){
                fri_s = hour +  ":" +minute;
                s_time.setText(fri_s);
                s_time.invalidate();
            }
            else if(week == "sat"){
                sat_s = hour + ":" + minute;
                s_time.setText(sat_s);
                s_time.invalidate();
            }
            else {
                Toast.makeText(getApplicationContext(), "요일을 먼저 선택해주세요.", Toast.LENGTH_SHORT).show();
            }
        }
    };

    private TimePickerDialog.OnTimeSetListener mTimeSetListener_e = new TimePickerDialog.OnTimeSetListener(){
        public void onTimeSet(TimePicker view, int hourOfDay, int min){
            if(hourOfDay<10) hour = "0"+String.valueOf(hourOfDay);
            else hour = String.valueOf(hourOfDay);

            if(min<10) minute = "0"+String.valueOf(min);
            else minute = String.valueOf(min);

            if(week == "sun") {
                sun_e =hour + ":" + minute;
                e_time.setText(sun_e);
                e_time.invalidate();
            }
            else if(week == "mon"){
                mon_e =hour + ":" + minute;
                e_time.setText(mon_e);
                e_time.invalidate();
            }
            else if(week == "tues"){
                tues_e =hour + ":" + minute;
                e_time.setText(tues_e);
                e_time.invalidate();
            }
            else if(week == "wens"){
                wens_e = hour + ":" + minute;
                e_time.setText(wens_e);
                e_time.invalidate();
            }
            else if(week == "thurs"){
                thurs_e =hour + ":" + minute;
                e_time.setText(thurs_e);
                e_time.invalidate();
            }
            else if(week == "fri"){
                fri_e = hour + ":" + minute;
                e_time.setText(fri_e);
                e_time.invalidate();
            }
            else if(week == "sat"){
                sat_e = hour +  ":" +minute;
                e_time.setText(sat_e);
                e_time.invalidate();
            }
            else {
                Toast.makeText(getApplicationContext(), "요일을 먼저 선택해주세요.", Toast.LENGTH_SHORT).show();
            }
        }
    };

    @Override
    protected Dialog onCreateDialog(int id){
        switch (id){
            case TIME_DIALOG_ID_S:
                return new TimePickerDialog(this, mTimeSetListener_s, mHour, mMinute, false);
            case TIME_DIALOG_ID_E:
                return new TimePickerDialog(this, mTimeSetListener_e, mHour, mMinute, false);
        }
        return null;
    }

    public void onClick(View view){
        if(view.getId() == R.id.sun){
            B_sun.setSelected(true); // true가 되면 색깔이 바뀜, 선택됨
            B_mon.setSelected(false);
            B_tues.setSelected(false);
            B_wens.setSelected(false);
            B_thurs.setSelected(false);
            B_fri.setSelected(false);
            B_sat.setSelected(false);
            week = "sun";
            s_time.setText(sun_s);
            e_time.setText(sun_e);
            s_time.invalidate();
            e_time.invalidate();
        }
        else if(view.getId() == R.id.mon){
            B_sun.setSelected(false);
            B_mon.setSelected(true);
            B_tues.setSelected(false);
            B_wens.setSelected(false);
            B_thurs.setSelected(false);
            B_fri.setSelected(false);
            B_sat.setSelected(false);
            week = "mon";
            s_time.setText(mon_s);
            e_time.setText(mon_e);
            s_time.invalidate();
            e_time.invalidate();
        }
        else if(view.getId() == R.id.tues){
            B_sun.setSelected(false);
            B_mon.setSelected(false);
            B_tues.setSelected(true);
            B_wens.setSelected(false);
            B_thurs.setSelected(false);
            B_fri.setSelected(false);
            B_sat.setSelected(false);
            week = "tues";
            s_time.setText(tues_s);
            e_time.setText(tues_e);
            s_time.invalidate();
            e_time.invalidate();
        }
        else if(view.getId() == R.id.wens){
            B_sun.setSelected(false);
            B_mon.setSelected(false);
            B_tues.setSelected(false);
            B_wens.setSelected(true);
            B_thurs.setSelected(false);
            B_fri.setSelected(false);
            B_sat.setSelected(false);
            week = "wens";
            s_time.setText(wens_s);
            e_time.setText(wens_e);
            s_time.invalidate();
            e_time.invalidate();
        }
        else if(view.getId() == R.id.thurs){
            B_sun.setSelected(false);
            B_mon.setSelected(false);
            B_tues.setSelected(false);
            B_wens.setSelected(false);
            B_thurs.setSelected(true);
            B_fri.setSelected(false);
            B_sat.setSelected(false);
            week = "thurs";
            s_time.setText(thurs_s);
            e_time.setText(thurs_e);
            s_time.invalidate();
            e_time.invalidate();
        }
        else if(view.getId() == R.id.fri){
            B_sun.setSelected(false);
            B_mon.setSelected(false);
            B_tues.setSelected(false);
            B_wens.setSelected(false);
            B_thurs.setSelected(false);
            B_fri.setSelected(true);
            B_sat.setSelected(false);
            week = "fri";
            s_time.setText(fri_s);
            e_time.setText(fri_e);
            s_time.invalidate();
            e_time.invalidate();
        }
        else if(view.getId() == R.id.sat){
            B_sun.setSelected(false);
            B_mon.setSelected(false);
            B_tues.setSelected(false);
            B_wens.setSelected(false);
            B_thurs.setSelected(false);
            B_fri.setSelected(false);
            B_sat.setSelected(true);
            week = "sat";
            s_time.setText(sat_s);
            e_time.setText(sat_e);
            s_time.invalidate();
            e_time.invalidate();
        }
        else if(view.getId() == R.id.start_time_s){
            showDialog(TIME_DIALOG_ID_S);
        }
        else if(view.getId() == R.id.end_time_s){
            showDialog(TIME_DIALOG_ID_E);
        }
    }
}
