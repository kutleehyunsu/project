package com.example.lee.g_lock;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by e12hs_000 on 2016-05-22.
 */
public class log_check extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.log_check);
    }

}
