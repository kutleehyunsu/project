package com.example.lee.g_lock;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class main extends AppCompatActivity {
    EditText user_id, user_pw;
    phpDown task;
    int db_total; //db 개수
    ArrayList A_name = new ArrayList();
    ArrayList A_id = new ArrayList(); // id 배열로 저장
    ArrayList A_pw = new ArrayList();
    ArrayList A_doorpw = new ArrayList();
    ArrayList A_ipaddr = new ArrayList();
    ArrayList A_serial = new ArrayList();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        task = new phpDown();
        user_id = (EditText)findViewById(R.id.edit_id);
        user_pw = (EditText)findViewById(R.id.edit_pw);
        task.execute("http://192.168.0.11/glock/login.php");
    }
    private class phpDown extends AsyncTask<String, Integer,String>{
        @Override
        protected String doInBackground(String... urls) {
            StringBuilder jsonHtml = new StringBuilder();
            try{
                // 연결 url 설정
                URL url = new URL(urls[0]);
                // 커넥션 객체 생성
                HttpURLConnection conn = (HttpURLConnection)url.openConnection();
                // 연결되었으면.
                if(conn != null){
                    conn.setConnectTimeout(10000);
                    conn.setUseCaches(false);
                    // 연결되었음 코드가 리턴되면.
                    if(conn.getResponseCode() == HttpURLConnection.HTTP_OK){
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                        for(;;){
                            // 웹상에 보여지는 텍스트를 라인단위로 읽어 저장.
                            String line = br.readLine();
                            if(line == null) break;
                            // 저장된 텍스트 라인을 jsonHtml에 붙여넣음
                            jsonHtml.append(line + "\n");
                        }
                        br.close();
                    }
                    conn.disconnect();
                }
            } catch(Exception ex){
                ex.printStackTrace();
            }
            return jsonHtml.toString();
        }
        protected void onPostExecute(String str){
            String id;
            String id_password;
            String doorlock_password;
            String user_name;
            String ip_address;
            String serial_number;

            try{
                JSONObject root = new JSONObject(str);
                JSONArray ja = root.getJSONArray("results");
                db_total = ja.length();
                for(int i=0; i<ja.length(); i++){
                    JSONObject jo = ja.getJSONObject(i);
                    id = jo.getString("id");
                    id_password = jo.getString("id_password");
                    doorlock_password = jo.getString("doorlock_password");
                    user_name = jo.getString("user_name");
                    ip_address = jo.getString("ip_address");
                    serial_number = jo.getString("serial_number");

                    A_id.add(id);
                    A_pw.add(id_password);
                    A_doorpw.add(doorlock_password);
                    A_name.add(user_name);
                    A_ipaddr.add(ip_address);
                    A_serial.add(serial_number);
                }
            }catch(JSONException e){
                e.printStackTrace();
            }
        }
    }

    public void onClick(View view){
        if(view.getId() == R.id.login_button){
            int count = 0;
            for(int i=0;i<db_total;i++){
                if(String .valueOf(user_id.getText()).equals(String .valueOf(A_id.get(i)))){
                    if(String .valueOf(user_pw.getText()).equals(String.valueOf(A_pw.get(i)))){
                        Toast toast = Toast.makeText(this,"환영합니다!", Toast.LENGTH_SHORT );
                        toast.show();
                        count--;
                        Intent intent = new Intent(this, menu.class);
                        intent.putExtra("id",String.valueOf(A_id.get(i)));
                        intent.putExtra("pw",String.valueOf(A_pw.get(i)));
                        intent.putExtra("doorpw",String.valueOf(A_doorpw.get(i)));
                        intent.putExtra("name",String.valueOf(A_name.get(i)));
                        intent.putExtra("ipaddr",String.valueOf(A_ipaddr.get(i)));
                        intent.putExtra("serial", String.valueOf(A_serial.get(i)));
                        startActivity(intent);

                    }
                }
                else    count++;
            }
            if(count== db_total-1){
                Toast toast = Toast.makeText(this, "PASSWORD가 맞지 않습니다.", Toast.LENGTH_SHORT );
                toast.show();
            }
            else if(count == db_total){
                Toast toast = Toast.makeText(this, "ID가 맞지 않습니다.", Toast.LENGTH_SHORT );
                toast.show();
            }
        }
        else if(view.getId() == R.id.enter){
            Intent intent = new Intent(this, enter.class);
            startActivity(intent);
        }
    }
}
