package com.example.lee.g_lock;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

/**
 * Created by e12hs_000 on 2016-05-22.
 */
public class remote extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.remote);
    }

    public void onClick(View view){
        if(view.getId() == R.id.remote){

        }
    }
}
